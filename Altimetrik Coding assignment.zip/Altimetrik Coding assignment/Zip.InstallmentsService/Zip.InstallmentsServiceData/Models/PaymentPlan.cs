﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zip.InstallmentsServiceData.Models
{
    public class PaymentPlan
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public decimal BuyAmount { get; set; }
        public DateTime BuyeDate { get; set; }
        public int NoOfInstallments { get; set; }
        public int FrequencyInDays { get; set; }

        public DateTime CreatedOn { get; set; }
        public Guid CreatedBy { get; set; }

        public List<Installment> Installments { get; set; }

    }
}
