﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsService.Interfaces
{
    public interface IInstallmentFactory
    {
        List<InstallmentData> CalculateInstallments(PaymentPlanData requestModel);
    }
}
