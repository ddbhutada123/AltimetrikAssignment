﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;
using AutoMapper;
using Zip.InstallmentsServiceData.Models;

namespace Zip.InstallmentsService.AutoMapper
{
    public class PaymentPlanMapping : Profile
    {
        public PaymentPlanMapping()
        {

            CreateMap<CreatePaymentPlanData, PaymentPlanData>();
            CreateMap<PaymentPlan, PaymentPlanData>();
            CreateMap<Installment, InstallmentData>();
        }

    }
}
