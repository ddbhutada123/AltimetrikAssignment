﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zip.InstallmentsServiceEntity
{
    /// <summary>
    /// Payment plan frequency
    /// </summary>
    public enum PaymentPlanFrequency
    {
        Daily = 1,
        Weekly = 2,
        FortNightly = 3,
        Monthly = 4
    }
}
