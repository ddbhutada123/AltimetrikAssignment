﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Zip.InstallmentsService.Interfaces;
using Zip.InstallmentsServiceEntity.DataTrnsfrObj;

namespace Zip.InstallmentsServiceAPI.Controllers
{
    [ApiController]
    public class PaymentController : ControllerBase
    {

        private readonly IPaymentPlanFactory _paymentPlanFactory;

        /// <summary>
        /// Intialization in Constructor
        /// </summary>
        /// <param name="paymentPlanFactory"></param>
        public PaymentController(IPaymentPlanFactory paymentPlanFactory)
        {
            _paymentPlanFactory = paymentPlanFactory;
        }

        /// <summary>
        /// Api to get payment plan along with installment by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        //[Authorize]
        [Route("api/PaymentPlan/{id}")]
        public ActionResult<PaymentPlanData> Get(Guid id)
        {
            try
            {
                var result = _paymentPlanFactory.GetById(id);
                if (result == null)
                {
                    return NotFound(new PaymentPlanData());
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

        }


        /// <summary>
        /// Api to create payment plan intallments
        /// </summary>
        /// <param name="_requestModel"></param>
        /// <returns></returns>
        [HttpPost]
        //[Authorize]
        [Route("api/PaymentPlan")]
        public ActionResult<PaymentPlanData> Create(CreatePaymentPlanData _requestModel)
        {
            try
            {
                _requestModel.Id = Guid.NewGuid();

                if (_requestModel.BuyDate == DateTime.MinValue)
                    _requestModel.BuyDate = DateTime.UtcNow;

                //Validate Request
                var validRequestViewModel = _paymentPlanFactory.ValidateCreateRequest(_requestModel);
                if (!validRequestViewModel.IsValid)
                {
                    return BadRequest(validRequestViewModel.Message);
                }

                //Create Plan
                var result = _paymentPlanFactory.Create(_requestModel);
                if (result == null)
                {
                    return NotFound(new PaymentPlanData());
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



    }
}
